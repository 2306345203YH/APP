<template>
	<view>
		<view class="box">
			<image mode="scaleToFill" src="../../static/input-box/caret-left.png" @click="prev()" style="width: 10%;" ></image>
			<image mode="aspectFit" :src="'data:image/jpg;base64,' + list[index]" style="width: 80%;" ></image>
			<image mode="scaleToFill" src="../../static/input-box/caret-right.png" @click="next()" style="width: 10%;" ></image>
			
		</view>
		<view>
			<uni-group title="识别结果" mode="card">
				<view>橘子:{{orange}}</view>
				<view>草莓:{{strawberry}}</view>
				<view>西红柿:{{tomato}}</view>
				<view>板栗:{{chestnut}}</view>
			</uni-group>
		</view>
		<view>
			<uni-group title="总数" mode="card">
				<view>橘子:{{orange2}}</view>
				<view>草莓:{{strawberry2}}</view>
				<view>西红柿:{{tomato2}}</view>
				<view>板栗:{{chestnut2}}</view>
			</uni-group>
		</view>
		<uni-section title="识别数目修正" type="line">
			<view class="box">
				<u-button text='修正' type="error" size='normal' @click="toggle('bottom')"></u-button>
				<u-button text='重新上传' type="warning" size='normal' @click="dddtup()" ></u-button>
				
			</view>
		</uni-section>
		<view>
			<!-- 修正弹窗 -->
			<uni-popup ref="popup" background-color="#fff" @change="change">
				<view class="popup-content" :class="{ 'popup-height': type === 'left' || type === 'right' }">
					<u-cell-group :border="true">
						<u-cell :border="true" title="橘子" ><u-number-box slot="right-icon" v-model="orange1" step="1" :min="-parseInt(orange)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="草莓" ><u-number-box slot="right-icon" v-model="strawberry1" step="1" :min="-parseInt(strawberry)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="西红柿" ><u-number-box slot="right-icon" v-model="tomato1" step="1" :min="-parseInt(tomato)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="板栗" ><u-number-box slot="right-icon" v-model="chestnut1" step="1" :min="-parseInt(chestnut)"  ></u-number-box></u-cell>
					</u-cell-group>
					<u-button text='修改确认' type="error" size='normal' @click="shuc()" ></u-button>
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script>
	import { pathToBase64, base64ToPath } from 'node_modules/image-tools'
	export default {
		data() {
			return {
				list:[],
				imageList:[],
				baseImageList:[],
				chestnut: 0,
				orange: 0,
				strawberry: 0,
				tomato: 0,
				chestnut1:0,
				orange1:0,
				strawberry1:0,
				tomato1:0,
				chestnut2:0,
				orange2:0,
				strawberry2:0,
				tomato2:0,
				type: 'center',
				data:'aa',
				count:'',
				countlist:[],
				index:0,
				ip:'',
			};
		},
		onLoad: function(option) {
			this.ip=uni.getStorageSync('ip')
			const item = JSON.parse(decodeURIComponent(option.data))
			this.list = item.data.img
			this.countlist = item.data.count
			let count = item.data.count
			this.orange=parseInt(this.countlist[this.index].orange)
			this.strawberry = parseInt(this.countlist[this.index].strawberry)
			this.chestnut = parseInt(this.countlist[this.index].chestnut)
			this.tomato = parseInt(this.countlist[this.index].tomato)
			for(let i =0;i<this.list.length;i++){
				this.orange2=this.orange2+parseInt(count[i].orange)
				this.strawberry2 = this.strawberry2+parseInt(count[i].strawberry)
				this.chestnut2 = this.chestnut2+parseInt(count[i].chestnut)
				this.tomato2 = this.tomato2+parseInt(count[i].tomato)
			}
		},
		methods: {
			change(e) {
					console.log('当前模式：' + e.type + ',状态：' + e.show);
					if(e.show=='false'){
						this.orange1=0
						this.chestnut1=0
						this.tomato1=0
						this.strawberry1 = 0
					}
					this.orange1=0
					this.chestnut1=0
					this.tomato1=0
					this.strawberry1 = 0
				},
			toggle(type) {
				this.type = type
				// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
				this.$refs.popup.open(type)
			},
			shuc(){
				let _this = this
				this.countlist[this.index].orange=parseInt(this.orange)+parseInt(_this.orange1)
				this.countlist[this.index].chestnut = parseInt(this.chestnut)+parseInt(_this.chestnut1)
				this.countlist[this.index].tomato = parseInt(this.tomato)+parseInt(_this.tomato1)
				this.countlist[this.index].strawberry = parseInt(this.strawberry)+parseInt(_this.strawberry1)
				this.orange=parseInt(this.orange)+parseInt(_this.orange1)
				this.chestnut = parseInt(this.chestnut)+parseInt(_this.chestnut1)
				this.tomato = parseInt(this.tomato)+parseInt(_this.tomato1)
				this.strawberry = parseInt(this.strawberry)+parseInt(_this.strawberry1)
				let count = this.countlist
				console.log(count)
				console.log(this.orange2)
				console.log(this.strawberry2)
				console.log(this.tomato2)
				console.log(this.chestnut2)
				console.log('---------------------')
				this.orange2=0
				this.strawberry2=0
				this.tomato2=0
				this.chestnut2=0
				for(let i =0;i<this.list.length;i++){
					
					console.log('+++++++++++++++==========')
					this.orange2=this.orange2+parseInt(count[i].orange)
					this.strawberry2 = this.strawberry2+parseInt(count[i].strawberry)
					this.chestnut2 = this.chestnut2+parseInt(count[i].chestnut)
					this.tomato2 = this.tomato2+parseInt(count[i].tomato)
					console.log(this.orange2)
					console.log(this.strawberry2)
					console.log(this.tomato2)
					console.log(this.chestnut2)
					console.log('==========================')
				}
				console.log('**********************')
				console.log(this.orange2)
				console.log(this.strawberry2)
				console.log(this.tomato2)
				console.log(this.chestnut2)
				console.log(this.countlist)
				this.$refs.popup.close()
			},
			next(){
				if(this.index<this.countlist.length-1){
					this.index+=1
					this.orange=parseInt(this.countlist[this.index].orange)
					this.strawberry = parseInt(this.countlist[this.index].strawberry)
					this.chestnut = parseInt(this.countlist[this.index].chestnut)
					this.tomato = parseInt(this.countlist[this.index].tomato)
				}else{
					uni.showToast({
						icon:'error',
						title:'到底了'
					})
					console.log('到底了')
				}
			},
			prev(){
				if(this.index>0){
					this.index-=1
					this.orange=parseInt(this.countlist[this.index].orange)
					this.strawberry = parseInt(this.countlist[this.index].strawberry)
					this.chestnut = parseInt(this.countlist[this.index].chestnut)
					this.tomato = parseInt(this.countlist[this.index].tomato)
				}else{
					uni.showToast({
						icon:'error',
						title:'到底了'
					})
					console.log('到底了')
				}
			},
			dddtup(){
				this.baseImageList = []
				this.list = []
				this.countlist=[]
				this.index = 0
				this.orange=0
				this.strawberry = 0
				this.chestnut = 0
				this.tomato = 0
				this.orange2=0
				this.strawberry2 = 0
				this.chestnut2 = 0
				this.tomato2 = 0
				uni.chooseImage({
					count:9,
					sizeType:['compressed'],
					sourceTupe:['camera','album'],
					success:(res)=>{
						// console.log(res)
						let count = 0
						for(var i=0;i<res.tempFilePaths.length;i++){
							pathToBase64(res.tempFilePaths[i])
							.then(path => {
								var data = path.replace(/^data:image\/\w+;base64,/,"")
							    this.baseImageList.push(data);//成功后利用concat方法追加到baseImageList中
								count++
								if(count==res.tempFilePaths.length){
									let aa = JSON.stringify(this.baseImageList)
									console.log(JSON.parse(aa))
									uni.request({
										method:'POST',
										header: {
											'Content-Type' : 'application/x-www-form-urlencoded',
										},
										url:'http://'+this.ip+':8000/duotp/',
										data:{
											image:aa,
										},
										success:(res) => {
											console.log(res)
											this.list = res.data.img
											let count22 = res.data.count
											this.countlist = res.data.count
											console.log(this.orange2)
											for(let i =0;i<this.baseImageList.length;i++){
												this.orange2=this.orange+parseInt(count22[i].orange)
												this.strawberry2 = this.strawberry+parseInt(count22[i].strawberry)
												this.chestnut2 = this.chestnut+parseInt(count22[i].chestnut)
												this.tomato2 = this.tomato+parseInt(count22[i].tomato)
											}
											console.log(this.orange2)
											this.orange=parseInt(this.countlist[this.index].orange)
											this.strawberry = parseInt(this.countlist[this.index].strawberry)
											this.chestnut = parseInt(this.countlist[this.index].chestnut)
											this.tomato = parseInt(this.countlist[this.index].tomato)
											console.log(this.countlist)
											
										},
										fail(res){
											console.log(res)
										}
									});
								}
							})
						}
					}
				})
			},
			
		},
	}
</script>

<style lang="scss">
.scroll-Y {
		height: 600rpx;
	}
.box{
		display: flex;
		flex-flow: row nowrap;
	}
</style>
