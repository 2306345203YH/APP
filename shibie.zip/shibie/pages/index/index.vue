<template>
	<view >
		<view class="box" >
			<image class="annu2" src="../../static/input-box/came.png" mode="aspectFit" @click="paizshibie()" >
				<text>拍照识别</text>
			</image>
		</view>
		<view class="box" >
			<image class="annu2" src="../../static/input-box/photo.png" mode="aspectFit" @click="bendishibie()"  >
				<text>本地识别</text>
			</image>
		</view>
		
	</view>
</template>

<script>
	import { pathToBase64, base64ToPath } from 'node_modules/image-tools'
	export default {
		data() {
			return {
				title: 'Hello',
				ip:'',
				img:[],
				chestnut:0,
				orange:0,
				strawberry:0,
				tomato:0,
				imagedata:[],
				baseimagedata:[],
			}
		},
		onLoad() {
			uni.setStorageSync('ip', '127.0.0.1')
			this.ip=uni.getStorageSync('ip')
		},
		methods: {
			bendishibie(){
				uni.chooseImage({
					count:9,
					sizeType:['compressed'],
					sourceTupe:['album'],
					success:(res)=>{
						// console.log(res)
						let count = 0
						for(var i=0;i<res.tempFilePaths.length;i++){
							pathToBase64(res.tempFilePaths[i])
							.then(path => {
								var data = path.replace(/^data:image\/\w+;base64,/,"")
							    this.baseimagedata.push(data);//成功后利用concat方法追加到baseImageList中
								count++
								if(count==res.tempFilePaths.length){
									let aa = JSON.stringify(this.baseimagedata)
									console.log(JSON.parse(aa))
									uni.request({
										method:'POST',
										header: {
											'Content-Type' : 'application/x-www-form-urlencoded',
										},
										url:'http://'+this.ip+':8000/duotp/',
										data:{
											image:aa,
										},
										success:(res) => {
											console.log(res)
											let item = encodeURIComponent(JSON.stringify(res))
											uni.navigateTo({
												url:'../duotp/duotp?data='+item
											})
											this.baseimagedata = []
											
										},
										fail(res){
											console.log(res)
										}
									});
								}
							})
						}
					}
				})
			},
			paizshibie(){
				uni.chooseImage({
					count:1,
					sizeType:['compressed'],
					sourceType:['camera'],
					success:(res) => {
						var basedata = res.tempFilePaths[0]
						var bimg = pathToBase64(basedata)
						.then(path => {
							var bimg1 = path.replace(/^data:image\/\w+;base64,/,"")
							this.imagedata.push(bimg1);
							// console.log(path)
							uni.request({
								method:'POST',
								header: {
									'Content-Type' : 'application/x-www-form-urlencoded',
								},
								url:'http://'+this.ip+':8000/onetp/',
								data:{
									image:this.imagedata,
								},
								success:(res) =>{
									// console.log(res)
									const json = res.data
									// console.log(json.img)
									uni.setStorageSync('image',json.img)
									this.chestnut = json.count[0].chestnut
									this.orange = json.count[0].orange
									this.strawberry = json.count[0].strawberry
									this.tomato = json.count[0].tomato
									uni.navigateTo({
										url:'../onetp/onetp?chestnut='+this.chestnut+'&strawberry='+this.strawberry+'&tomato='+this.tomato+'&orange='+this.orange
									})
								}
							})
						})
						
					}
				})
			},
		},
}
</script>

<style lang="scss" >
	page{background-color: #f0f0f0; }
	.annu2{
		width: 45%;
		// margin-top: 10%;
		height: 320rpx;
		display:block;
		margin:0 auto;
		background-color: #0de5de;
		border-radius:25%;
		// margin: 100upx;
		// margin-top: 50px;
	}
	.a1{
		background-color: blue;
		transform: scale(1.1);
	}
	.box{
		
		text-align: center;
		margin-top: 10%;
	}
	.warp {
		padding: 10px;
	}
	.heti{
		display: flex;
		flex-flow: row nowrap;
	}
</style>
