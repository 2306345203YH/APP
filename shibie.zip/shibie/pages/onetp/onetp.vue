<template>
	<view>
		<view>

			<image mode="aspectFit" :src="'data:image/jpg;base64,' +img" style="width: 100%;" ></image>
			<!-- <image mode="aspectFit" src="data:image/png;base64,{{img}}" style="width: 100%;" ></image> -->
		</view>
		<view>
			<uni-group title="识别结果" mode="card">
				<view>橘子:{{orange}}</view>
				<view>草莓:{{strawberry}}</view>
				<view>西红柿:{{tomato}}</view>
				<view>板栗:{{chestnut}}</view>
			</uni-group>
		</view>
		
		<uni-section title="识别数目修正" type="line">
			<view class="box">
				
				<u-button text='修正' type="error" size='normal' @click="toggle('bottom')"></u-button>
				<u-button text='重新拍摄' type="warning" size='normal' @click="paiz()" ></u-button>
			</view>
		</uni-section>
		<view>
			<!-- 修正弹窗 -->
			<uni-popup ref="popup" background-color="#fff" @change="change">
				<view class="popup-content" :class="{ 'popup-height': type === 'left' || type === 'right' }">
					<u-cell-group :border="true">
						<u-cell :border="true" title="橘子" ><u-number-box slot="right-icon" v-model="orange1" step="1" :min="-parseInt(orange)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="草莓" ><u-number-box slot="right-icon" v-model="strawberry1" step="1" :min="-parseInt(strawberry)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="西红柿" ><u-number-box slot="right-icon" v-model="tomato1" step="1" :min="-parseInt(tomato)"  ></u-number-box></u-cell>
						<u-cell :border="true" title="板栗" ><u-number-box slot="right-icon" v-model="chestnut1" step="1" :min="-parseInt(chestnut)"  ></u-number-box></u-cell>
					</u-cell-group>
					<u-button text='修改确认' type="error" size='normal' @click="shuc()" ></u-button>
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script>
	import { pathToBase64, base64ToPath } from 'node_modules/image-tools'
	export default {
		data() {
			return {
				vlan:0,
				chestnut:0,
				orange:0,
				strawberry:0,
				tomato:0,
				ip:'',
				img:'',
				count:'',
				chestnut1:0,
				orange1:0,
				strawberry1:0,
				tomato1:0,
				type: 'center',
				imagedata:[],
			};
		},
		onLoad:function(option){
			this.ip = uni.getStorageSync('ip')
			this.img = uni.getStorageSync('image')
			console.log(this.img)
			this.chestnut = parseInt(option.chestnut)
			this.orange = parseInt(option.orange)
			this.strawberry = parseInt(option.strawberry)
			this.tomato = parseInt(option.tomato)
			this.count = '[{"chestnut":'+option.chestnut+',"orange":'+option.orange+',"strawberry":'+option.strawberry+',"tomato":'+option.tomato+'}]'
			
		},
		methods:{
			change(e) {
				console.log('当前模式：' + e.type + ',状态：' + e.show);
				if(e.show=='false'){
					this.orange1=0
					this.chestnut1=0
					this.tomato1=0
					this.strawberry1 = 0
				}
				this.orange1=0
				this.chestnut1=0
				this.tomato1=0
				this.strawberry1 = 0
			},
			toggle(type) {
				this.type = type
				// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
				this.$refs.popup.open(type)
			},
			shuc(){
				let _this = this
				this.orange=parseInt(this.orange)+parseInt(_this.orange1)
				this.chestnut = parseInt(this.chestnut)+parseInt(_this.chestnut1)
				this.tomato = parseInt(this.tomato)+parseInt(_this.tomato1)
				this.strawberry = parseInt(this.strawberry)+parseInt(_this.strawberry1)
				this.$refs.popup.close()
			},
			paiz(){
				uni.chooseImage({
				  	count: 1,
				    sizeType: [ 'compressed'],
				    sourceType: ['camera','album'], //这要注意，camera掉拍照，album是打开手机相册
				    success: (res)=> {
						var basedata = res.tempFilePaths[0]
						var bimg = pathToBase64(basedata)
						.then(path => {
							var bimg1 = path.replace(/^data:image\/\w+;base64,/,"")
							this.imagedata.push(bimg1);
							uni.request({
								method:'POST',
								header: {
									'Content-Type' : 'application/x-www-form-urlencoded',
								},
								url:'http://'+this.ip+':8000/onetp/',
								data:{
									image:this.imagedata,
								},
								success:(res) =>{
									// console.log(res)
									const json = res.data
									// console.log(json.img)
									this.img = json.img
									this.chestnut = json.count[0].chestnut
									this.orange = json.count[0].orange
									this.strawberry = json.count[0].strawberry
									this.tomato = json.count[0].tomato
								}
							})
						}) 
				     }
					 
				 }); 
			},
			
		}
	}
</script>

<style lang="scss">
	.button {
		align-items: center;
		justify-content: center;
		flex: 1;
		height: 35px;
		margin: 0 5px;
		border-radius: 5px;
	}
	.button-text {
		color: #fff;
		font-size: 12px;
	}
	.box{
		display: flex;
		flex-flow: row nowrap;
	}
	.popup-content {
		align-items: center;
		justify-content: center;
		padding: 15px;
		height: 250px;
		background-color: #fff;
	}
	.popup-guoy{
		align-items: center;
		justify-content: center;
		height: 100px;
		background-color: #fff;
	}
</style>
